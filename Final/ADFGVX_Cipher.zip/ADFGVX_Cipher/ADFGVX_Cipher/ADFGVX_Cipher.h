/*
CIS 4362 - Introduction to Cryptology
Final Project
Andrew Helms
12/09/20
*/

#pragma once

#include "resource.h"
#include "atlstr.h"
#include <string>

std::wstring s2ws(const std::string& s);
/*
CIS 4362 - Introduction to Cryptology
Final Project
Andrew Helms
12/09/20
*/

#pragma once
#include <string>
#include <vector>

std::string adfgvxE(std::string pKey, std::string cKey, std::string input); //Encrypt function
std::string adfgvxD(std::string pKey, std::string cKey, std::string input); //Decrypt function
CIS 4362 - Intro to Cryptology
Ex01
Andrew Helms
9/16/20

The code was written in C++. To make and run the code, make and g++ must be installed on the Unix machine. To make all programs, type "make all" or "make" in the terminal in the directory that the files are located. To run the programs, type "./<programName> <args>" in the terminal in the directory that the file is located. There are no known bugs.

CIS 4362 - Introduction to Cryptology
Ex03
Andrew Helms
10/16/20

This code was written in C++. To make and run the code, make and g++ must be installed on the Unix machine. To make all programs, type "make all" or "make" in the terminal in the directory that the files are located. To run the programs, type "./<programName> <args>" in the terminal in the directory that the file is located. There are no known bugs in any of the programs.